**************************************************************************
*             Hello and thanks for using my application.                 *
*                                                                        *
* Coded By xfileFIN: http://battlelog.battlefield.com/bf4/user/xfileFIN/ *
* Source code: https://github.com/Razer2015/MorseDecoder                 *
*                                                                        *
**************************************************************************
*                                                                        *
*     Light calculator included in the zip is from s1ingular1ty2         *
*                       https://goo.gl/3NmQZ9                            *
*                                                                        *
**************************************************************************
*                                                                        *
*    Some parts of the code are taken from the Morse Code Interpreter    *
*                      which is coded by Shivam Kalra                    *
*                           http://goo.gl/UdSosl                         *
*                                                                        *
**************************************************************************